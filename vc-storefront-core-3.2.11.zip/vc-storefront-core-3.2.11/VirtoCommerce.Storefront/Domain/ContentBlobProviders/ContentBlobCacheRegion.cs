using VirtoCommerce.Storefront.Model.Common.Caching;

namespace VirtoCommerce.Storefront.Domain
{
    public class ContentBlobCacheRegion : CancellableCacheRegion<ContentBlobCacheRegion>
    {
    }
}
