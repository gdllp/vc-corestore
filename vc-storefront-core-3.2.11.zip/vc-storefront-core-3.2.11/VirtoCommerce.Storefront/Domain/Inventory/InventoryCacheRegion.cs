using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VirtoCommerce.Storefront.Model.Common.Caching;

namespace VirtoCommerce.Storefront.Domain
{
    public class InventoryCacheRegion : CancellableCacheRegion<InventoryCacheRegion>
    {
    }
}
