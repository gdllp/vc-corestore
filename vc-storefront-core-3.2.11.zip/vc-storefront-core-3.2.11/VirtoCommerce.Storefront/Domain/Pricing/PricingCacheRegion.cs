using VirtoCommerce.Storefront.Model.Common.Caching;

namespace VirtoCommerce.Storefront.Domain
{
    public class PricingCacheRegion : CancellableCacheRegion<PricingCacheRegion>
    {
    }
}
