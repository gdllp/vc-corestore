Please provide detailed information about your issue, thank you!

Version info: 
- Browser version: 
- Platform version: 
- Storefront version: 

### Expected behavior

### Actual behavior

### Steps to reproduce
1.
2.
3.
