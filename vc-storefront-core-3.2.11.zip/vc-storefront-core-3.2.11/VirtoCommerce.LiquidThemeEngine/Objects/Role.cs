using System;
using System.Collections.Generic;
using System.Text;
using DotLiquid;

namespace VirtoCommerce.LiquidThemeEngine.Objects
{
    public class Role : Drop
    {
        public string Id { get; set; }
        public string Name { get; set; }
    }

}
