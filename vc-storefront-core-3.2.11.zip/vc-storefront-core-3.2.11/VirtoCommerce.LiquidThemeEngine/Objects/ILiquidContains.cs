namespace VirtoCommerce.LiquidThemeEngine.Objects
{
    public interface ILiquidContains
    {
        bool Contains(object value);
    }
}
