using DotLiquid;

namespace VirtoCommerce.LiquidThemeEngine.Objects
{
    public partial class Description : Drop
    {
        public string Type { get; set; }

        public string Content { get; set; }
    }
}