using System;
using System.Collections.Generic;
using System.Text;
using VirtoCommerce.Storefront.Model.Common.Caching;

namespace VirtoCommerce.LiquidThemeEngine
{
    public class ThemeEngineCacheRegion : CancellableCacheRegion<ThemeEngineCacheRegion>
    {
    }
}
