using VirtoCommerce.Storefront.Model.Common;

namespace VirtoCommerce.Storefront.Model.Order
{
    public class CustomerOrderSearchResult : GenericSearchResult<CustomerOrder>
    {
    }
}
