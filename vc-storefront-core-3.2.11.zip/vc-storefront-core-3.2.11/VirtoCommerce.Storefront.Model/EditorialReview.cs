namespace VirtoCommerce.Storefront.Model
{
    public partial class EditorialReview : LocalizedString
    {
        public string ReviewType { get; set; }
    }
}