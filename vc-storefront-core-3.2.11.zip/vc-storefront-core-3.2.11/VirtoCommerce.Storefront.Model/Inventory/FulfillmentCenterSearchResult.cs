using VirtoCommerce.Storefront.Model.Common;

namespace VirtoCommerce.Storefront.Model.Inventory
{
    public class FulfillmentCenterSearchResult : GenericSearchResult<FulfillmentCenter>
    {
    }
}
