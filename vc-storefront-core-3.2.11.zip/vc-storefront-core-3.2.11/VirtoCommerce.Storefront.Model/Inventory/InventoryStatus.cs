namespace VirtoCommerce.Storefront.Model.Inventory
{
    public enum InventoryStatus
    {
        Disabled,
        Enabled,
        Ignored
    }
}
