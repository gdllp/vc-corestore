namespace VirtoCommerce.Storefront.Model
{
    public enum StorefrontNotificationType
    {
        Success,
        Info,
        Warning,
        Error
    }
}