namespace VirtoCommerce.Storefront.Model
{
    public enum AmountType
    {
        Absolute,
        Relative
    }
}