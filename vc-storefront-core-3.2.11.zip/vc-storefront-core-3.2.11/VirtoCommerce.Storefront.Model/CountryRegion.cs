namespace VirtoCommerce.Storefront.Model
{
    public partial class CountryRegion
    {
        public string Name { get; set; }
        public string Code { get; set; }
    }
}
