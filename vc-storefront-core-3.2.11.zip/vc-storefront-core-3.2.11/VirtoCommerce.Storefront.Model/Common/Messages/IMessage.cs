namespace VirtoCommerce.Storefront.Model.Common.Messages
{
    public interface IMessage
    { }
}