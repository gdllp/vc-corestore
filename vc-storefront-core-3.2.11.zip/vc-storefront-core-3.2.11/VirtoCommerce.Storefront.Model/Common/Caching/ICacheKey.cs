using System;
using System.Collections.Generic;
using System.Text;

namespace VirtoCommerce.Storefront.Model.Common
{
    public interface ICacheKey
    {
        string GetCacheKey();
    }
}
