namespace VirtoCommerce.Storefront.Model
{
    public interface IHasLanguage
    {
        Language Language { get; }
    }
}