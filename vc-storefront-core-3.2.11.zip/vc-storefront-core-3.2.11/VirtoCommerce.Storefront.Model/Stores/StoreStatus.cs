namespace VirtoCommerce.Storefront.Model.Stores
{
    public enum StoreStatus
    {
        Open,
        Closed,
        RestrictedAccess
    }
}
