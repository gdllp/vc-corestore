namespace VirtoCommerce.Storefront.Model.Quote
{
    public class QuoteItemsCount
    {
        public string Id { get; set; }
        public int ItemsCount { get; set; }
    }
}
