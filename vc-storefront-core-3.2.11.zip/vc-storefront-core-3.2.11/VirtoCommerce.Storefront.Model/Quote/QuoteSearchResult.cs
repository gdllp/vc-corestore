using VirtoCommerce.Storefront.Model.Common;

namespace VirtoCommerce.Storefront.Model.Quote
{
    public class QuoteSearchResult : GenericSearchResult<QuoteRequest>
    {
    }
}
