namespace VirtoCommerce.Storefront.Model.Quote
{
    public partial class TierPriceFormModel
    {
        public decimal Price { get; set; }

        public long Quantity { get; set; }
    }
}