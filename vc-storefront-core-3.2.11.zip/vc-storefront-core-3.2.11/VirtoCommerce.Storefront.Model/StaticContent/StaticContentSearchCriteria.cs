namespace VirtoCommerce.Storefront.Model.StaticContent
{
    public partial class StaticContentSearchCriteria
    {
        public string Keyword { get; set; }

        public string Layout { get; set; }

        public string SearchIn { get; set; }
    }
}