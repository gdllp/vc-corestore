using VirtoCommerce.Storefront.Model.Common;

namespace VirtoCommerce.Storefront.Model.Security
{
    public class UserSearchResult : GenericSearchResult<User>
    {
    }
}
