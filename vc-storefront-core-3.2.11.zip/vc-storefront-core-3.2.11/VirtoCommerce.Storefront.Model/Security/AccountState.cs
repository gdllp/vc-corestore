namespace VirtoCommerce.Storefront.Model.Security
{
    public enum AccountState
    {
        PendingApproval,
        Approved,
        Rejected
    }
}
