namespace VirtoCommerce.Storefront.Model.BulkOrder
{
    public class BulkOrderItem
    {
        public string Sku { get; set; }

        public int Quantity { get; set; }
    }
}