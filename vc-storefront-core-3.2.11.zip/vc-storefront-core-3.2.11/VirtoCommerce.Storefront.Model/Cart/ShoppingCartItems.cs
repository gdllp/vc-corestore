namespace VirtoCommerce.Storefront.Model.Cart
{
    public class ShoppingCartItems
    {
        public int ItemsCount { get; set; }
    }
}
