namespace VirtoCommerce.Storefront.Model.Cart.ValidationErrors
{
    public class UnavailableError : ValidationError
    {

    }
}