namespace VirtoCommerce.Storefront.Model.Cart
{
    public partial class ChangeCartItemQty
    {
        public string LineItemId { get; set; }
        public int Quantity { get; set; }
    }
}
