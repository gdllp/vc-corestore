using VirtoCommerce.Storefront.Model.Common;

namespace VirtoCommerce.Storefront.Model.Cart
{
    public class ShoppingCartSearchResult : GenericSearchResult<ShoppingCart>
    {
    }
}
