using VirtoCommerce.Storefront.Model.Common;

namespace VirtoCommerce.Storefront.Model.Subscriptions
{
    public class SubscriptionSearchResult : GenericSearchResult<Subscription>
    {
    }
}
